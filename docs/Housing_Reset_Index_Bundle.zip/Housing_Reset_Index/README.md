# Housing Reset + Index + Master Doc

Install:

```bash
cd /mnt/data/housing_reset_index_bundle/Housing_Reset_Index
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```
