# Housing Policy Research Workspace

This repository contains a ready‑to‑use scaffold for housing policy research and
analysis.  It pulls together a set of sensible defaults for version control,
Quarto document templates, automation hooks and a Raycast extension to
streamline common tasks (adding sources, generating drafts and sweeping
legislation).  The directory structure mirrors the one described in the
recommendation and can be safely synced to iCloud or another cloud service for
easy access on macOS and iOS devices.

## Directory layout

```
housing_policy_scaffold/
├── 00_admin/                 # policies, templates and configuration
│   ├── settings.yaml         # stub configuration for API keys and settings
│   └── templates/            # Quarto and bill templates
│       ├── policy_brief_apa7.qmd  # Quarto policy brief template using APA 7 style
│       └── nyc_bill_template.md   # NYC Council bill drafting shell
├── 10_sources/               # PDFs, URLs and other research materials
├── 20_notes/                 # Markdown notes and annotations
├── 30_drafts/                # Draft Quarto or Pages files
├── 40_outputs/               # Rendered PDFs, DOCX, HTML, etc.
├── 50_data/                  # CSV or Parquet datasets
├── 60_logs/                  # Logs from fact‑checks and automation tasks
├── zotero/                   # Exported BetterBibTeX or CSLJSON bibliography
├── raycast-extension/        # Raycast extension skeleton (TypeScript)
├── shortcuts/                # Shortcut blueprints for macOS/iOS Shortcuts
└── README.md                 # This file
```

The scaffold includes stub code and templates.  You should customise the
`settings.yaml` file with your own API keys and adjust the Quarto templates to
match your organisation’s preferences.  The Raycast extension provides
simple commands that call an HTTP endpoint; point it at your own service or
modify it to talk directly to OpenAI’s Assistants API.
